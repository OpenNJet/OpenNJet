## 预构建文件
预生成文件，用于适配OpenHarmony系统，以3.2版本为主

### 汇编文件

需要先安装x86_64-linux-android-clang，Linux或Mac下示例：
```bash
cd ~/tools/

wget -c https://dl.google.com/android/repository/android-ndk-r25c-linux.zip
unzip android-ndk-r25c-linux.zip
cd android-ndk-r25c/toolchains/llvm/prebuilt/linux-x86_64/bin

# 创建软链接
ln -s x86_64-linux-android28-clang x86_64-linux-android-clang

vim ~/.bashrc

# 将如下加入到.bashrc中
export PATH=~/tools/android-ndk-r25c/toolchains/llvm/prebuilt/linux-x86_64/bin:$PATH

source ~/.bashrc
```

代码根目录下执行：
```bash
util/create_asm_file.sh
```

### 头文件

按照不同平台定制的头文件

- crypto/buildinf.h
- include/crypto/bn_conf.h
- include/crypto/dso_conf.h
- include/openssl/opensslconf.h
- include/openssl/symbol_prefix.h
